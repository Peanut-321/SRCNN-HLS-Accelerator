# ELEN90096 SRCNN FPGA 加速项目执行计划

文档状态：**待确认草案（Draft for Review）**  
版本：0.1  
日期：2026-09-10  
关联规格：[spec.md](./spec.md)

> 本计划只定义工作阶段、产出、验证门禁、依赖和风险。当前停在文档确认点，不进入代码实现。

## 1. 总体执行原则

1. **规格优先。** 输入尺寸、padding/stride、预处理、权重格式、数据精度、误差阈值和 DMA 接口未确认前，不在实现中静默假设。
2. **正确性优先于优化。** 任一版本未通过与 Golden Reference 的逐层比较，不得进入下一优化阶段。
3. **一次改变一类主要变量。** float → fixed、`PIPELINE`、`UNROLL`、`ARRAY_PARTITION`、line buffer、`DATAFLOW` 分阶段引入，以便定位错误并形成报告消融表。
4. **保留基线。** 每个通过门禁的阶段形成独立版本，不覆盖前一版本。
5. **统一回归。** 所有版本运行同一组输入、权重和逐层输出检查。
6. **从第一版开始收集数据。** 每个 HLS 版本都记录 latency、II、clock、LUT、FF、DSP、BRAM、URAM 和正确性，不等到最后补数据。
7. **所有结论可复现。** 保存工具版本、配置、随机 seed、权重 checksum、输入尺寸、pragma、综合/实现报告和原始 benchmark 数据。

## 2. 阶段依赖与硬门禁

```text
G0 规格冻结
 ↓
G1 Golden Reference 全测试通过
 ↓
G2 无优化 float HLS：C-sim / synthesis / co-sim 通过
 ↓
G3 数值格式达到冻结误差门槛
 ↓
G4 PIPELINE / UNROLL / PARTITION 各优化版本正确且可综合
 ↓
G5 line buffer / DATAFLOW 长帧无死锁并 timing closure
 ↓
G6 KV260 板级正确、稳定、计时可重复
 ↓
G7 报告数据完整、可追溯、可复算
```

任何门禁失败时，回到最近一个通过的版本修复；不得同时继续叠加新的优化。

## 3. 版本和实验记录约定

建议为每个候选版本分配稳定标签：

| 标签 | 含义 |
|---|---|
| `V0-golden` | 顺序 C/C++ Golden Reference |
| `V1-hls-naive-float` | 无优化浮点 HLS |
| `V2-fixed-*` | 数值格式候选 |
| `V3-pipeline-*` | Pipeline 候选 |
| `V4-unroll-partition-*` | 并行因子和存储分区候选 |
| `V5-linebuffer-*` | line buffer / tiling 候选 |
| `V6-dataflow-*` | 多层 dataflow 候选 |
| `V7-board-final` | 最终板级版本 |

每次实验至少记录：

- 版本标签和 source revision；
- Vitis/Vivado/PYNQ 版本、目标 part/platform；
- 输入尺寸、layout、数据类型和精度配置；
- 权重文件 checksum、随机 seed；
- 目标与实际 clock；
- pragma 和并行因子；
- C-sim、co-sim、synthesis、implementation 的通过状态；
- 误差、latency、II、资源和带宽；
- 失败原因或选择/淘汰理由。

## 4. 阶段 0：规格冻结与实验框架

### 具体产出物

- 经确认的 [spec.md](./spec.md)；
- “已确认项 / TBD / blocker” 决策表；
- 最终 tensor、weights、bias 的逻辑和物理布局定义；
- padding、stride、色彩空间、归一化、预处理和后处理规则；
- 正式模型权重、测试图片及 checksum；
- float 和 fixed-point 正确性指标与冻结阈值；
- 目标 Vitis/Vivado/PYNQ 版本、KV260 platform 和目标 clock；
- 实验记录表与统一 benchmark 计时边界；
- 实际 overlay 的资源基线和可用于 kernel 的工程预算。

### 完成/正确标准

- 所有会改变算法输出、buffer 大小或接口协议的问题已有答案；
- 未解决项目明确标为 blocker，不允许被默认值掩盖；
- 任意实验可由配置、seed、weights checksum 和版本号重现；
- kernel-only 与 end-to-end 的计时边界已经书面冻结。

### 前置依赖

- Canvas assignment、rubric、starter code；
- Lecture 01、Lecture 08；
- 教师提供的权重、输入和输出样例；
- 目标 KV260 软件镜像和 platform 信息。

### 预估风险

- 把通用 SRCNN 的 Y 通道、bicubic、valid padding 当成课程规定；
- 把 `256k logic cells` 错当成 LUT 数；
- 使用器件总资源而忽略 base platform、DMA 和 interconnect 占用；
- 把 DDR 理论峰值当成可持续 DMA 带宽；
- Canvas 与 lecture/starter code 的版本不一致；
- 尚未确定 tensor layout 就开始写 host/HLS 接口。

## 5. 阶段 1：Golden Reference

### 具体产出物

- 顺序 C/C++ Conv1、Conv2、Conv3 和完整 SRCNN；
- 独立测试驱动；
- 输入、每层中间输出、最终输出的 dump 格式；
- 固定 seed 的测试向量及预期输出；
- 测试结果摘要；
- Golden Reference 运行说明；
- 必要时使用独立 NumPy/PyTorch 实现作为二级 oracle，但其语义必须与冻结规格一致。

### 必须覆盖的测试

- 固定 seed 随机输入/权重/bias；
- 全零输入；
- 全一输入与可预测权重；
- 中心、边、角 impulse；
- 非对称 kernel，用于检查 kernel 方向；
- 正负值和跨零 bias，用于检查 `bias → ReLU`；
- Conv3 负输出保留；
- 可手算的小尺寸、稀疏权重或 identity/channel-route 用例；
- 最小合法尺寸、非方形尺寸和边界像素；
- 官方权重与代表性真实图像；
- 非法尺寸、短文件或参数数量错误的失败行为。

### 完成/正确标准

- 同一输入、seed 和权重的输出可重复；
- 输入、权重和 bias 数量/形状检查全部通过；
- 手算用例逐元素一致；
- 与独立 oracle 比较满足冻结的 `atol/rtol`；
- 每一层都可以独立比较，能够定位到首个出错层、通道和坐标；
- 所有测试结果和正式 Golden 输出均已冻结，后续不得为了适配硬件而修改。

### 前置依赖

- 阶段 0 的数据契约、padding/stride、预处理和数值规则；
- 正式或临时明确标记的权重和输入数据。

### 预估风险

- `CHW/HWC`、`NCHW/NHWC` 混用；
- `OIHW/HWIO` 权重布局混用；
- kernel row/column 或 h/w 索引对调；
- padding 边界 off-by-one；
- bias 被放在通道累加循环内，导致重复相加；
- 在 bias 前执行 ReLU；
- 错误地给 Conv3 加 ReLU 或 clamp；
- 使用同一段有 bug 的逻辑同时生成“参考”和待测输出；
- 浮点累加顺序不同引起小误差，被误判为算法错误。

## 6. 阶段 2：无优化 HLS 移植

### 具体产出物

- 与 Golden 语义一一对应的直接嵌套循环 HLS 版本；
- 最简单、明确的顶层接口；
- 复用 Golden 测试向量的 HLS testbench；
- C simulation、C synthesis 和 RTL co-simulation 报告；
- 第一份 baseline latency、II、clock 和资源表；
- HLS 输出的逐层对比结果。

### 完成/正确标准

- C simulation 与 Golden 满足 float 容差；
- RTL co-simulation（若课程环境采用）完成且结果通过；
- 设计可综合，无动态分配、越界或未支持结构；
- 综合报告包含 latency、II、目标 clock、LUT、FF、DSP、BRAM/URAM；
- 即使性能很差，也已形成可信、可复现的 `V1-hls-naive-float` 基线；
- 不依赖未定义行为或 testbench 恰好满足的数组深度。

### 前置依赖

- 阶段 1 的 Golden、测试向量和逐层输出；
- 阶段 0 冻结的顶层函数和数据格式。

### 预估风险

- C-sim 正确但 co-sim 因接口深度或 stream 数量错误而卡住；
- 大数组被推断为寄存器，LUT/FF 爆炸；
- 初始化循环或运行时尺寸使设计不可综合；
- 只检查最终图像，导致无法定位中间层错误；
- HLS 估计 clock 与实现后 clock 被混用；
- 无优化版本已经暗含某个 pragma，破坏后续消融比较。

## 7. 阶段 3：数据类型与数值精度优化

### 具体产出物

- 使用真实权重和校准输入得到的逐层动态范围；
- 输入、权重、bias、乘积、累加器、中间输出和最终输出的位宽表；
- rounding、overflow/saturation 模式说明；
- 多组位宽候选的误差、资源、latency 对比；
- 饱和/溢出事件统计；
- 被选择的精度方案及选择理由。

### 完成/正确标准

- 先有正确的 float HLS 版本，再评估 fixed-point；
- 每种候选均运行完整 Golden 回归；
- 最终候选满足事先冻结的 max-abs、MAE、RMSE 和 PSNR/SSIM 门槛；
- 零溢出，或每个饱和事件均有明确、可接受的解释；
- 累加器位宽包含最坏情况增长和工程裕量；
- 图像质量损失与“硬件实现相对 float Golden 的数值误差”分开报告。

### 前置依赖

- 阶段 2 的 float HLS baseline；
- 阶段 1 的完整回归集和真实数据；
- 阶段 0 冻结的数值阈值。

### 预估风险

- 只看输入范围，没有估算多项累加增长；
- bias 位宽或 scale 与累加器不兼容；
- ReLU 前发生溢出，但负值被 ReLU 掩盖；
- signed/unsigned、截断和舍入行为不一致；
- 定点量化和数据布局优化同时进行，错误无法定位；
- 只看最终图片“肉眼相似”，没有逐层数值比较；
- 为减少位宽牺牲过多精度，却没有得到明显资源收益。

## 8. 阶段 4：`PIPELINE` 与基本存储端口准备

### 具体产出物

- 不同循环层级的 `PIPELINE` 候选；
- HLS schedule、loop dependency 和 memory port 分析；
- 必要的局部 buffer；
- 目标 II 与实际 II 的对照；
- 优化前后 latency、clock 和资源表。

### 完成/正确标准

- 选定 pipeline 层级有明确原因；
- 达到目标 II，或能用真实 dependency/port conflict 解释未达到原因；
- 所有回归测试通过；
- 目标 clock 可满足，资源仍在工程预算内；
- latency 统计包含 pipeline fill/drain，而不是只引用 steady-state II。

### 前置依赖

- 阶段 2 的正确 HLS 基线；
- 通常使用阶段 3 选定精度，也可先在 float 上验证结构后再迁移，但版本必须分开记录。

### 预估风险

- pipeline 了错误的循环层级；
- 累加循环存在 loop-carried dependency；
- 单/双端口 BRAM 无法满足每周期访问；
- 初始化、边界或清零循环拖慢整帧；
- 看到 `II=1` 就误认为整个输出像素或整帧每周期完成；
- HLS schedule 看似改善，但实现后 routing 导致 Fmax 下降。

## 9. 阶段 5：`UNROLL` 与 `ARRAY_PARTITION` 设计空间探索

### 具体产出物

- 对输入通道、输出通道和 kernel 维度的候选展开方案；
- 对应的 cyclic/block/complete array partition 方案；
- 并行因子 sweep 表；
- 每个候选的正确性、latency、II、Fmax、DSP、BRAM、LUT、FF；
- 最终并行因子及其资源/性能选择依据。

### 完成/正确标准

- 展开因子与实际可用读写端口一致；
- 不超过 DSP、BRAM、LUT/FF 工程预算；
- C-sim/co-sim 正确，synthesis 可行；
- 实现频率没有因过大 fanout/routing 明显崩溃，或该代价被量化；
- 性能提升由报告数据证明，而不是只根据“乘法器更多”推断；
- 至少保留小、中、大三类有代表性的并行候选用于消融。

### 前置依赖

- 阶段 4 的 schedule 和端口瓶颈；
- 阶段 3 的数据位宽；
- 阶段 0 的实际资源预算。

### 预估风险

- 先 unroll，但数组没有足够端口，II 不变；
- `complete partition` 把大数组拆成大量寄存器/LUT；
- 乘法没有按预期映射至 DSP；
- Conv1/Conv2 全展开超过 1,248 DSP；
- adder tree 过深或 fanout 过大导致 timing failure；
- 某层局部 latency 降低，但 DDR 或最慢 stage 成为新的瓶颈；
- 为满足端口要求复制权重，导致 BRAM 使用意外增加。

## 10. 阶段 6：line buffer、sliding window 与 tiling

### 具体产出物

- Conv1 9×9 和 Conv3 5×5 的 line buffer/sliding window 结构；
- Conv2 1×1 通道归约的数据供给方案；
- tile 尺寸、halo、尾块和边界处理规则；
- 全帧/分块模式下的外存读写量模型；
- 最小尺寸、随机尺寸、非 tile 整除尺寸的测试；
- 优化前后 DDR bytes/frame、BRAM 和 latency 对比。

### 完成/正确标准

- 中心、边、角和 tile 边界均与 Golden 一致；
- 窗口 warm-up/flush 不产生多余或遗漏输出；
- 非 tile 整除的尾行/尾列正确；
- 每个输入像素的重复 DDR 加载显著减少，并由字节数证明；
- BRAM/URAM、带宽和整帧 latency 在预算内；
- 不要求在片上保存完整的 64-channel 中间图，除非资源报告证明可行。

### 前置依赖

- 阶段 5 的并行因子和存储端口需求；
- 阶段 0 冻结的尺寸、padding 和 stride；
- 阶段 1 的边界测试向量。

### 预估风险

- halo 范围或行切换 off-by-one；
- tile 边界重复、漏算或输出顺序错误；
- line buffer 的有效数据时刻与输出坐标不一致；
- 动态尺寸使 buffer 边界错误；
- 为减少 DDR 流量而耗尽 BRAM；
- 中间 feature map 或 FIFO 位宽造成意外的大存储需求；
- 只在整齐尺寸上测试，遗漏尾块问题。

## 11. 阶段 7：跨层 `DATAFLOW`

### 具体产出物

- `Conv1 → ReLU → Conv2 → ReLU → Conv3` 的 producer-consumer 阶段划分；
- stream/FIFO 数据格式、宽度、深度和 TLAST/计数规则；
- 各 stage 的生产率、消费率、II 和瓶颈表；
- FIFO 深度依据和高水位观察；
- dataflow C-sim/co-sim、长帧和连续多帧测试；
- dataflow 前后 latency、throughput 和资源对比。

### 完成/正确标准

- 每个 stage 独立正确后才允许组合；
- 长帧和连续多帧无 deadlock、underflow、overflow 或数据丢失；
- 输出元素数量、次序和 frame boundary 正确；
- FIFO 有合理裕量，不是仅通过增大深度让某个仿真偶然通过；
- 最终稳态 throughput 可以由最慢 stage 的速率解释；
- 组合后仍满足工程资源预算和 implementation timing closure；
- 输出满足 Golden 容差。

### 前置依赖

- 阶段 6 的窗口和 tile 结构；
- 阶段 5 已选定的并行度；
- 阶段 3 已冻结的数据宽度；
- 各层单独版本均通过回归。

### 预估风险

- FIFO 太小或生产/消费速率不匹配导致死锁；
- stream 深度只在 C-sim/co-sim 中可用，板上仍卡住；
- 不同 stage 对 frame 起止的理解不同；
- static line-buffer 状态没有在帧间正确 reset；
- DATAFLOW 导致 buffer/函数资源复制，超过预算；
- 最慢 stage 没有优化，增加其他 stage 并行度却不提升吞吐；
- 错把单帧 latency 的倒数当成连续流 throughput。

## 12. 阶段 8：PYNQ + DMA 部署

### 具体产出物

- implementation 通过的 bitstream 和硬件描述文件；
- AXI-Lite 控制接口与 AXI-Stream/AXI-MM 数据通路；
- PYNQ host 执行流程；
- 输入/输出 buffer 大小、打包、对齐和 cache 管理说明；
- 板级 smoke test、正式正确性测试、连续多帧稳定性测试；
- DMA timeout/hang 的诊断信息；
- PS→PL、PL→PS 和完整 device-path 的计时数据；
- 实测 DMA 有效带宽。

### 完成/正确标准

- `.bit/.hwh` 与同一硬件版本匹配；
- 输入尺寸、字节数、AXI word packing、DMA length 和 TLAST 一致；
- 板上逐层/最终结果满足冻结容差；
- 多次运行和连续多帧不挂起、不残留上一帧状态；
- post-implementation 无 timing violation 和阻塞性 DRC；
- 实际 clock 与报告采用的 clock 一致；
- kernel-only 与 end-to-end/device-path 时间分开报告；
- 若 PYNQ `transfer/wait` 覆盖 DMA 与 streaming kernel，必须标为 `DMA + kernel/device-path`，不能错误命名为 kernel-only。

### 前置依赖

- 阶段 7 的稳定 HLS IP；
- 阶段 0 冻结的接口和平台；
- 阶段 1 的板级测试向量；
- 可用的 KV260、系统镜像、PYNQ 和 DMA overlay 流程。

### 预估风险

- `.bit/.hwh` 版本不一致；
- DMA word width、length、packing、TKEEP/TLAST 错误导致 hang；
- PYNQ buffer 非连续、未对齐或 cache 未同步；
- send/receive/start/wait 顺序错误；
- PS 预处理与 HLS tensor layout 不一致；
- 只计 host API 调用时间，没有等硬件真正完成；
- 板上 clock 与 HLS target clock 不同；
- static 状态或 reset 信号造成第二帧以后错误；
- Linux 调度噪声影响单次计时。

## 13. 阶段 9：系统基准、Status Update 与 Final Report

### 具体产出物

- 冻结的最终设计版本；
- CPU baseline 与 FPGA 的统一 benchmark；
- kernel-only、device-path 和 end-to-end 三类时间；
- 单帧 latency 与连续多帧 throughput；
- 优化消融表及原始数据；
- correctness/PSNR/SSIM 表；
- post-implementation 资源、clock、timing、带宽和可选功耗结果；
- 系统架构图、数据流图和时间分解图；
- Status Update slides；
- Final Report；
- HLS、PYNQ host 和 rubric 要求的提交产物；
- 从干净环境复现实验的说明。

### 完成/正确标准

- CPU 与 FPGA 使用同一输入、权重、算法语义、精度边界和预/后处理；
- 先 warm-up，再重复 `N` 次，并报告 `N`、mean、median、standard deviation，必要时 p95；
- `speedup = 相同工作范围的 CPU 时间 / FPGA 时间`；
- kernel-only 和 end-to-end 的 speedup 分开计算；
- throughput 基于连续 `N` 帧稳定完成率，不简单使用单帧 latency 的倒数；
- 资源表同时包含绝对值、平台可用量和百分比，并注明 post-synthesis/post-implementation 来源；
- 所有表格注明输入尺寸、clock、数据类型、工具版本和实现标签；
- 报告中的每个关键数字都能从原始 CSV/log/report 复算；
- 所有 rubric 条目逐项核对完成。

### 前置依赖

- 阶段 8 的稳定板级版本；
- 阶段 2–7 保存的各优化版本和实验记录；
- Canvas 的汇报和报告 rubric。

### 预估风险

- 用 CPU end-to-end 时间对比 FPGA kernel-only 时间；
- CPU 与 FPGA 使用不同精度、预处理或输出尺寸；
- 只报告最佳的一次测量；
- 混淆 latency、II 和 throughput；
- 混淆 MAC/s 与 GOPS，未说明 1 MAC 按 1 还是 2 operations；
- 只报资源百分比，不报绝对值和可用总量；
- 用 HLS 估计资源代替 post-implementation 资源；
- 忽略 DMA、buffer allocation、cache 和 host 预处理；
- 最后才收集数据，导致优化版本或报告缺失；
- 报告结论无法由保存的原始数据复现。

## 14. 里程碑映射与建议缓冲

课件列出的课程节点为 Golden Reference 5 Oct、Status Update 12 Oct、Final Report 19 Oct*；最终以 Canvas 为准。

| 课程里程碑 | 应至少完成的内部阶段 | 建议内部缓冲 |
|---|---|---|
| Golden Reference | 阶段 0–1 | 正式提交前至少预留数天做独立复核和格式检查 |
| Status Update | 阶段 2 完成，阶段 3–6 至少有部分可信结果 | 汇报前冻结架构图、baseline 和首轮消融数据 |
| Final Report | 阶段 0–9 | 截止前预留板级复测、报告校对和提交包验证时间 |

不在本计划中擅自指定内部日期；待确认团队成员、Canvas 细则和可用板卡时间后再排具体日程。

## 15. 总风险登记表

| 风险 | 早期检测方法 | 缓解措施 |
|---|---|---|
| 通道/权重布局混用 | 单权重、单通道、impulse 测试 | 冻结逻辑布局和显式转换点 |
| padding/stride 边界错误 | 角/边像素、最小尺寸、非对称 kernel | 逐层坐标级比较 |
| bias/ReLU 顺序错误 | 负 bias、正负输入测试 | 规定 `accumulate → bias → activation` |
| fixed-point 溢出 | 动态范围、饱和计数、逐层误差 | 宽累加器起步，再逐步缩位宽 |
| 展开度超资源 | 每次候选先 csynth | 并行因子 sweep，设置 80%–85% 工程预算 |
| 存储端口限制 II | HLS schedule/port conflict | partition、banking、局部缓存 |
| line buffer/tile 边界错误 | halo、尾块、非整除尺寸测试 | 独立边界回归和输出计数 |
| DATAFLOW deadlock | 长帧、连续帧 co-sim/板测 | 速率分析、FIFO 深度依据、timeout |
| DDR 成为瓶颈 | bytes/frame 与 DMA benchmark | line buffer、tiling、burst、减少中间回写 |
| DMA hang | TLAST/长度计数和超时诊断 | 统一 word packing 与传输协议 |
| 性能比较不公平 | 审核计时边界 | kernel-only/end-to-end 各自同边界比较 |
| 报告不可复现 | 从原始记录重算一张表 | 自动化记录配置、版本和原始数据 |

## 16. 当前停止点

本轮只完成 `spec.md` 和 `plan.md` 草案。下一步必须先由项目成员确认：

- 是否接受文档中的范围和阶段门禁；
- 是否已经有 Canvas assignment、starter code、正式权重和测试图片可用于关闭 TBD；
- 文档路径和后续项目目录结构是否合适；
- float/fixed、padding/stride、I/O layout 和 DMA 接口的课程规定。

**在收到确认前，不开始 Golden Reference 或任何 HLS/PYNQ 代码实现。**
