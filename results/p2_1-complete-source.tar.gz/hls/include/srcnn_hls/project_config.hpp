#pragma once

#include <cstdint>

namespace srcnn_hls {
namespace config {

// -----------------------------------------------------------------------------
// Fixed channel/kernel topology (source: course project specification; not TBD).
// -----------------------------------------------------------------------------
constexpr int kConv1InChannels = 1;
constexpr int kConv1OutChannels = 64;
constexpr int kConv1KernelHeight = 9;
constexpr int kConv1KernelWidth = 9;

constexpr int kConv2InChannels = 64;
constexpr int kConv2OutChannels = 32;
constexpr int kConv2KernelHeight = 1;
constexpr int kConv2KernelWidth = 1;

constexpr int kConv3InChannels = 32;
constexpr int kConv3OutChannels = 1;
constexpr int kConv3KernelHeight = 5;
constexpr int kConv3KernelWidth = 5;

// Frozen-P1 vector compatibility parameters, not a resolved deployment
// contract. Dependency: course clarification of stride/padding. P2.1 must use
// stride 1 and select same (4/0/2) or valid (0/0/0) at runtime to reproduce the
// committed gates. When the blocker closes, change these centralized values
// and deliberately re-baseline only if the official contract differs.
constexpr int kStrideHeight = 1;
constexpr int kStrideWidth = 1;
constexpr int kConv1SamePadHeight = 4;
constexpr int kConv1SamePadWidth = 4;
constexpr int kConv2SamePadHeight = 0;
constexpr int kConv2SamePadWidth = 0;
constexpr int kConv3SamePadHeight = 2;
constexpr int kConv3SamePadWidth = 2;

static_assert(kStrideHeight > 0 && kStrideWidth > 0,
              "convolution strides must be positive");

// Derived from topology. These are deliberately not repeated as magic numbers
// in the accumulator type declarations.
constexpr int kConv1MacTerms =
    kConv1InChannels * kConv1KernelHeight * kConv1KernelWidth;
constexpr int kConv2MacTerms =
    kConv2InChannels * kConv2KernelHeight * kConv2KernelWidth;
constexpr int kConv3MacTerms =
    kConv3InChannels * kConv3KernelHeight * kConv3KernelWidth;

static_assert(kConv1MacTerms == 81, "Conv1 topology changed unexpectedly");
static_assert(kConv2MacTerms == 64, "Conv2 topology changed unexpectedly");
static_assert(kConv3MacTerms == 800, "Conv3 topology changed unexpectedly");
static_assert(kConv1OutChannels == kConv2InChannels &&
                  kConv2OutChannels == kConv3InChannels,
              "adjacent SRCNN channel counts must match");

// -----------------------------------------------------------------------------
// TBD-derived structural parameters. Keep every unresolved architecture input
// in this file so the arithmetic policy does not move when csynth forces a
// loop/buffer redesign.
// -----------------------------------------------------------------------------

// Dependency: the two open blockers (colour/pre-upsample contract) and the
// course image-size contract. Placeholder 64x64 covers all five committed P1
// vectors (largest 33x29); it is NOT the final deployment resolution.
constexpr int kMaxInputHeight = 64;
constexpr int kMaxInputWidth = 64;

// Dependency: the same colour/pre-upsample blockers plus the course image
// contract. Zero means "not yet fixed: accept a runtime H0/W0 up to the test
// maxima above". Replace both with positive deployment dimensions once the
// blocker is answered; do not infer them from the committed micro vectors.
constexpr int kDeploymentInputHeight = 0;
constexpr int kDeploymentInputWidth = 0;

// Dependency: P0a's implemented overlay resource budget. P2.1 keeps natural
// serial loops, so all factors remain one. These are placeholders only and are
// not consumed by an UNROLL pragma in this phase.
constexpr int kConv1UnrollFactor = 1;
constexpr int kConv2UnrollFactor = 1;
constexpr int kConv3UnrollFactor = 1;

// Dependency: kernel topology (known). The future line-buffer storage contains
// K-1 previous rows. P2.1 records the derived shape but does not implement the
// line buffer yet.
constexpr int kConv1LineBufferRows = kConv1KernelHeight - 1;
constexpr int kConv2LineBufferRows = kConv2KernelHeight - 1;
constexpr int kConv3LineBufferRows = kConv3KernelHeight - 1;

// Dependency: confirmed H0/W0 and first csynth memory report. Placeholder means
// "whole committed test frame", not a final tiling decision.
constexpr int kTileHeight = kMaxInputHeight;
constexpr int kTileWidth = kMaxInputWidth;

// -----------------------------------------------------------------------------
// TBD-derived numeric contract.
// -----------------------------------------------------------------------------

struct PositiveRational {
    std::uint64_t numerator;
    std::uint64_t denominator;
};

// Dependency: official model/input dynamic ranges. The wide 32/24 placeholder
// is selected only so the all-ones 13x13 valid sanity path can be represented;
// it is not a resource/performance choice and must be revisited with the
// official weights before P2.2 is accepted.
constexpr int kDataTotalBits = 32;
constexpr int kDataIntegerBits = 24;

// Dependency: input normalization contract. Placeholder is |X| <= 1.
constexpr PositiveRational kInputAbsMax = {1, 1};

// Dependency: official weight files. All three |W|max values are conservative
// placeholders for the committed random vectors, whose weights lie in [-1,1].
constexpr PositiveRational kConv1WeightAbsMax = {1, 1};
constexpr PositiveRational kConv2WeightAbsMax = {1, 1};
constexpr PositiveRational kConv3WeightAbsMax = {1, 1};

// Dependency: official bias files. Placeholders cover the committed random
// vectors; bias is included in the pre-activation accumulator bound.
constexpr PositiveRational kConv1BiasAbsMax = {1, 1};
constexpr PositiveRational kConv2BiasAbsMax = {1, 1};
constexpr PositiveRational kConv3BiasAbsMax = {1, 1};

// A tightened accumulator is an explicit OPT-D action. The enabled bit is
// separate from the value: zero is a legal ap_fixed integer-width value and is
// therefore not used as a sentinel. Default is always the derived worst case.
struct AccumulatorIntegerOverride {
    bool enabled;
    int integer_bits;
};

constexpr AccumulatorIntegerOverride kConv1AccumulatorOverride = {false, 0};
constexpr AccumulatorIntegerOverride kConv2AccumulatorOverride = {false, 0};
constexpr AccumulatorIntegerOverride kConv3AccumulatorOverride = {false, 0};

// P2.1 requires the declared worst-case chain to fit data_t. Set this true only
// as an explicit, documented experiment; P2.2 must then count/diagnose every
// narrowing saturation with a wider shadow value.
constexpr bool kAllowWorstCaseDataSaturation = false;

}  // namespace config
}  // namespace srcnn_hls
