# q24_8 local SRCNN board delivery

Build: routed timing/DRC and bitstream gates passed. Physical board validation
is PENDING. Source: 5f0216704cdd7ba70e2c8a493469c2df97e32259.

Revision V3 fixes the permanently asserted auxiliary reset in V2.
Generated HWH wiring is checked and reset-release simulation must pass.
Do not execute or merge files from V2. Physical inference is still PENDING.

Upload/extract this entire directory inside your board Project directory.
Keep it separate from the other format and from the dummy overlay.
Open SRCNN_board_test.ipynb: inspect first, then enable RUN_PREFLIGHT and run
the control-path check. Only after that passes enable RUN_BOARD for inference.
Both switches default to false. Never run old notebooks or compatibility patches.
The notebook is editable; all runtime Python, hardware and reference files
remain protected by the manifest. XSA is archived under build_reports, not
beside the runtime BIT/HWH pair (PYNQ 3.0.1 compatibility).

Each run checks all 65,025 output words. It tests warmup, ten repeated frames,
changed input/model, original-model restoration and overlay reload. Results
are written to a new directory. Benchmark includes model loading and DMA,
not pure kernel latency. Ten samples are a preliminary benchmark, not a
large statistical study. The changed case is a synthetic restart test,
not another official dataset image.

Use a fresh directory for this revision: HPM1/HPC0 at B0000000/B0010000.
Do not merge these files into the old HPM0 directory, which may retain XSA.
Runtime uses direct MMIO polling; the original upstream host is preserved
under build_reports for provenance, and is NOT the executable runtime.

Only one notebook/kernel may use the PL hardware at a time. Finish and close
the first format's kernel before programming the other. On transfer failure,
do not continue blindly. If buffers are retained, keep the kernel alive and
reset/power-cycle the board before closing it. Do not uninstall or update PYNQ.

Offline inspection (no board required):
python aero_board_test.py

Hardware results must not be labelled PASS before physical execution.
