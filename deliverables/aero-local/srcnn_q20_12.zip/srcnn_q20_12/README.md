# q20_12 local SRCNN board delivery

Build: routed timing/DRC and bitstream gates passed. Physical board validation
is PENDING. Source: 18281e76b9070b6801620a8548c7ae8b72f47db5.

Upload/extract this entire directory inside your board Project directory.
Keep it separate from the other format and from the dummy overlay.
Open SRCNN_board_test.ipynb: run the inspection cell first. Only then enable
RUN_BOARD in the next cell. The default is false and programs no FPGA.

Each run checks all 65,025 output words. It tests warmup, ten repeated frames,
changed input/model, original-model restoration and overlay reload. Results
are written to a new directory. Benchmark includes model loading and DMA,
not pure kernel latency. Ten samples are a preliminary benchmark, not a
large statistical study. The changed case is a synthetic restart test,
not another official dataset image.

Only one notebook/kernel may use the PL hardware at a time. Finish and close
the first format's kernel before programming the other. On transfer failure,
do not continue blindly. If buffers are retained, keep the kernel alive and
reset/power-cycle the board before closing it. Do not uninstall or update PYNQ.

Offline inspection (no board required):
python aero_board_test.py

Hardware results must not be labelled PASS before physical execution.
